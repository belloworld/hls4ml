//Numpy array shape (1,)
//Min 0.605036556721
//Max 0.605036556721
//Number of zeros 0

bias_default_t b3[1] = {0.605036556721};
