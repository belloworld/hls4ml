//Numpy array shape (1,)
//Min 0.6050365567207336
//Max 0.6050365567207336
//Number of zeros 0

bias_default_t b3[1] = {0.6050365567207336};
